
    (!!!) ONLY IN EXTREME CASES
    
    addon.xml (fixed addon.xml for launching Add to Lib in old style) - limited functionality!
    addon_new.xml (normal 1.0.12 addon.xml) - full functionality.
    
    For using old style addon.xml replace original addon.xml in context.addtolib folder.
    For back to normal style replace addon.xml in context.addtolib folder addon_new.xml (rename addon_new.xml to addon.xml).
    
    OLD STYLE CHANGE LAUNCHING service.py (run old_service.py). 
    New options from changelog.txt will not work fully!   