# service.boot.video
Play video, song or script at Kodi startup

Default video courtsey of Samfisher @ https://www.youtube.com/channel/UCTxCEZ4GQkPr9PnwQt-l-Pw

Current WIP, please leave suggestions or issues in the Issues section.
